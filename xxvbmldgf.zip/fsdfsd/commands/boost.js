const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');
const fs = require('fs');

const cooldowns = new Map();
const ALLOWED_CHANNEL_ID = '1330811739809517640';
const COOLDOWN_TIME = 60 * 60 * 1000;
const ACCOUNTS_FILE = './booster_accounts.txt';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('boost')
        .setDescription('Belirli bir kanalda booster hesabı almanızı sağlar.'),

    async execute(interaction) {
        const { channel, user, guild } = interaction;

        if (channel.id !== ALLOWED_CHANNEL_ID) {
            const errorEmbed = new EmbedBuilder()
                .setColor(Colors.DarkButNotBlack)
                .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
                .setDescription(`Bu komutu sadece <#${ALLOWED_CHANNEL_ID}> kanalında kullanabilirsiniz.`);

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        const lastUsed = cooldowns.get(user.id);
        const now = Date.now();

        if (lastUsed && now - lastUsed < COOLDOWN_TIME) {
            const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsed)) / (60 * 1000));
            const cooldownEmbed = new EmbedBuilder()
                .setColor(Colors.Red)
                .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
                .setDescription(`Booster hesabınızı 1 saat içinde yalnızca bir kez alabilirsiniz.\nKalan süre: **${remainingTime} dakika**.`);

            await interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
            return;
        }

        const accounts = fs.readFileSync(ACCOUNTS_FILE, 'utf-8').split('\n').filter(line => line.trim() !== '');
        if (accounts.length === 0) {
            const noAccountEmbed = new EmbedBuilder()
                .setColor(Colors.Orange)
                .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
                .setDescription('Şu anda gönderilecek booster hesabı bulunmamaktadır.');

            await interaction.reply({ embeds: [noAccountEmbed], ephemeral: true });
            return;
        }

        const account = accounts.shift();
        fs.writeFileSync(ACCOUNTS_FILE, accounts.join('\n'));

        const [username, password] = account.split(':');
        const serverIconURL = guild.iconURL({ dynamic: true, size: 512 }) || null;

        const dmEmbed = new EmbedBuilder()
            .setColor(0x800080)
            .setTitle('Booster Hesabınız')
            .setThumbnail(serverIconURL)
            .addFields(
                { name: 'Kullanıcı Adı  <a:heartgen:1330846864743989321>', value: username || 'Bilinmiyor', inline: false },
                { name: 'Şifre  <a:passgen:1330846845450190868>', value: password || 'Bilinmiyor', inline: false }
            )
            .setFooter({ text: 'Bizi Tercih Ettiğiniz İçin Teşekkür Ederiz ! 👋' });

        try {
            await user.send({ embeds: [dmEmbed] });
        } catch (err) {
            const dmErrorEmbed = new EmbedBuilder()
                .setColor(Colors.Red)
                .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
                .setDescription('DM kutunuza mesaj gönderilemedi. Lütfen DM kutunuzu açık hale getirin.');

            await interaction.reply({ embeds: [dmErrorEmbed], ephemeral: true });
            return;
        }

        cooldowns.set(user.id, now);

        const successEmbed = new EmbedBuilder()
            .setColor(0x800080)
            .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
            .setDescription('**Booster Hesabınız** Başarıyla DM Üzerinden Gönderilmiştir <a:boostgen:1330844524142002258>')
            .setThumbnail(user.displayAvatarURL());

        await interaction.reply({ embeds: [successEmbed] });
    },
};
