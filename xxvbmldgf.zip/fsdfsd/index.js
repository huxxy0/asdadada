const { Client, Collection, GatewayIntentBits, REST, Routes, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers, // Üyeleri dinlemek için gerekli
        GatewayIntentBits.GuildPresences, // Durum güncellemelerini dinlemek için gerekli
    ]
});
client.commands = new Collection();

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
    commands.push(command.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(config.token);

(async () => {
    try {
        console.log('Komutlar Discord API\'ye kaydediliyor...');

        await rest.put(
            Routes.applicationCommands(config.clientId), 
            { body: commands },
        );

        console.log('Komutlar başarıyla kaydedildi.');
    } catch (error) {
        console.error('Komutlar kaydedilirken bir hata oluştu:', error);
    }
})();

client.once('ready', () => {
    console.log(`Bot hazır: ${client.user.tag}`);
});

// Durum güncellemelerini dinle ve belirlenen yazıya göre rol ver/rol al
const TARGET_STATUS = "discord.gg/nalorant"; // Durumda aranacak yazı
const TARGET_ROLE_ID = "1330819435321233448"; // Verilecek rolün ID'si

client.on(Events.PresenceUpdate, async (oldPresence, newPresence) => {
    const member = newPresence.member;
    if (!member || !member.guild) return;

    const guild = member.guild;

    // Rol kontrolü
    const targetRole = guild.roles.cache.get(TARGET_ROLE_ID);
    if (!targetRole) {
        console.error(`Rol bulunamadı: ${TARGET_ROLE_ID}`);
        return;
    }

    // Yeni durumdaki "custom status"u al
    const newCustomStatus = newPresence.activities.find(
        activity => activity.type === 4 && activity.state
    )?.state;

    // Durumda yazı olup olmadığını kontrol et
    if (newCustomStatus && newCustomStatus.includes(TARGET_STATUS)) {
        // Kullanıcının rolü var mı, kontrol et
        if (!member.roles.cache.has(TARGET_ROLE_ID)) {
            await member.roles.add(targetRole).catch(console.error);
            console.log(`${member.user.tag} durumunda hedef yazı bulundu. Rol verildi.`);
        }
    } else {
        // Kullanıcı rolü taşıyorsa ve yazıyı kaldırdıysa rolü al
        if (member.roles.cache.has(TARGET_ROLE_ID)) {
            await member.roles.remove(targetRole).catch(console.error);
            console.log(`${member.user.tag} durumundan hedef yazıyı kaldırdı. Rol geri alındı.`);
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        await interaction.reply({ content: 'Komut çalıştırılırken bir hata oluştu!', ephemeral: true });
    }
});

client.login(config.token);
